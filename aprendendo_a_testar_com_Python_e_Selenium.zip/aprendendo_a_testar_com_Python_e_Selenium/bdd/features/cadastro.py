from behave import given, when, then

@given(u'que acesso ao website para efetuar um cadastro')
def step_impl(context):
    pass


@when(u'preencho os campos com dados válidos')
def step_impl(context):
    pass


@when(u'clico em Enviar')
def step_impl(context):
    pass

@then(u'o cadastro do usuário é efetuado com os dados são exibidos na tabela abaixo dos campos')
def step_impl(context):
    pass
