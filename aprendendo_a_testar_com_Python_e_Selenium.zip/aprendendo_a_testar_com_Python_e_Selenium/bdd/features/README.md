Baixar o Python
Baixar o Chromedriver e criar o caminho C:\webdrivers\chromedriver\83\chromedriver.exe na pasta c
Utilizar o Selenium Behave
Foi utilizado o VSCode para escrever e rodar o código
Acessar no terminal o caminho '.../Pesquisa de viagens com Python e Selenium\bdd\features>' para acessar os steps
Utilizar no terminal o comando behave para rodar o teste 