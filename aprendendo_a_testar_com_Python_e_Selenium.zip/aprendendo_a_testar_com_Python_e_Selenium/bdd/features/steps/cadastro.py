from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By 
from selenium.common.exceptions import NoSuchElementException 
from selenium.webdriver.support.ui import WebDriverWait
from time import sleep
import unittest



@given(u'que acesso ao website para efetuar um cadastro')
def step_impl(context):
    chrome_path = 'C:\webdrivers\chromedriver\84\chromedriver.exe'
    context.web = webdriver.Chrome(chrome_path)
    context.web.get('http://www.aprendendotestar.com.br/treinar-automacao.php')
    context.web.maximize_window()


@when(u'preencho os campos com dados válidos')
def step_impl(context):
    context.element = context.web.find_element_by_name("form_usuario")
    context.element.click()
    context.element.send_keys("mariasouza")
    sleep(3)
    context.element = context.web.find_element_by_name("form_senha")
    context.element.click()
    context.element.send_keys("abc123")
    sleep(3)
    context.element = context.web.find_element_by_name("form_nome")
    context.element.click()
    context.element.send_keys("Maria Souza")
    sleep(3)
    
       
@when(u'clico em Enviar')
def step_impl(context): 
    context.element = context.web.find_element_by_xpath('/html/body/section/section[2]/div/form/table/tbody/tr[7]/td/input').click()
    sleep(3)  

@then(u'o cadastro do usuário é efetuado com os dados são exibidos na tabela abaixo dos campos')
def step_impl(context):
    context.element = context.web.find_element_by_xpath('/html/body/section/section[2]/div/table/tbody/tr[2]/td[3]')
    assert context.element.text == 'mariasouza'
